package com.example.baitap02_d

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
val color1 = Color(0xFFE53935)
val color2 = Color(0xFFFDD835)
val color3 = Color(0xFF03A9F4)
val color4 = Color(0xFFF06292)
val color5 = Color(0xFF8E24AA)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ComplexLayout()
        }
    }
}
@Composable
fun ComplexLayout() {
    Column(modifier = Modifier.fillMaxSize()) {
        ColoredBox(
            text = "1",
            color = color1,
            modifier = Modifier.weight(1f)
        )
        Row(modifier = Modifier.weight(3f)) {
            ColoredBox(
                text = "2",
                color = color2,
                modifier = Modifier.weight(1f)
            )
            Column(modifier = Modifier.weight(2f)) {
                ColoredBox(
                    text = "3",
                    color = color3,
                    modifier = Modifier.weight(2f)
                )
                Row(modifier = Modifier.weight(1f)) {
                    ColoredBox(
                        text = "4",
                        color = color4,
                        modifier = Modifier.weight(1f)
                    )
                    ColoredBox(
                        text = "5",
                        color = color5,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}
@Composable
fun ColoredBox(
    text: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        color = color
    ) {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}